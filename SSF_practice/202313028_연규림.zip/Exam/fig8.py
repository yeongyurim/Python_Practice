num1, num2 = input("예제 입력 : ").split(' ')
num1 = int(num1[::-1])
num2 = int(num2[::-1])
print("예제 출력 :",num2-num1)