num = int(input("예제 입력 : "))
for i in range(1,num+1):
    for j in range(i):
        print("*",end="")
    print()
