text = input("입력: ")
print("출력:", list(text[::-1]))