kor=90
mat=80
eng=100
sum=kor+mat+eng
print("kor",kor)
print("mat",mat)
print("eng",eng)
print("sum",sum)